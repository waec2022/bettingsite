# Sure2OddToday: central control (editor + Worker)

One editor (`editor.html`) controls everything. One Worker does the scheduled work and keeps your credentials. The website (`index.html`) only shows what is published in `data.json`.

## Where things live
| What | Where | Visible in GitHub? |
|---|---|---|
| Website data: matches, predictions, results, accumulators, booking codes, packages, arbitrage, site text, affiliate links, ad code | `data.json` in your repo | Yes (it is public site content) |
| API key, GitHub token | Worker KV, encrypted (AES-GCM) | Never |
| Automation settings, schedule, request counters, cache, run log | Worker KV | No |
| `ADMIN_TOKEN` | Cloudflare secret (the only one) | No |
| Admin token on your phone | This browser (Forget button in the editor) | No |

KV stays because a public repo cannot hold secrets, and request counters/caches change every few minutes: committing them to GitHub would redeploy your site constantly. You set KV up once and never open it again.

## One-time setup (phone browser is fine)
1. **GitHub repo**: put `index.html`, `editor.html` and the `worker` folder in the repo root. (The old `functions` folder is no longer used; delete it.)
2. **Cloudflare > Workers & Pages > KV > Create namespace** `S2O`. Copy its ID into `worker/wrangler.toml` (edit on GitHub).
3. **Workers & Pages > Create > Import a repository**, root directory `worker`. Deploy. Copy the Worker address (`https://....workers.dev`).
4. Worker > Settings > Variables and Secrets: add **one secret**, `ADMIN_TOKEN` (a long random password, at least 32 characters). Do not change it later: your saved keys are encrypted with it, so changing it means re-entering them.
5. Open `editor.html` > **API Management**: paste the Worker address and ADMIN_TOKEN, Connect. Then:
   - **GitHub**: owner, repository, branch and a fine-grained token (Contents: read and write on that one repo). Test connection.
   - **API key**: paste your API-Football key, Save, Test connection (shows plan, requests used, remaining, reset time).
6. **Automation**: check leagues and hours, tick Automation enabled, Save settings. Press **Fetch now > Run everything due** once.

After that nothing needs to be done daily. Every change you make later (API key, provider switch, schedule, affiliate links, ad code, predictions) is made in the editor.

## Editor sections
Dashboard, **API Management** (connections, provider on/off, usage, request protection, manual fetch), **Automation** (schedule, predictions, accumulator, rollovers, odds comparison, expiry, caching), **Matches & Predictions** (imported + manual, publish/unpublish, results, booking codes), **Accumulators**, Rollover Packages, Odds & Arbitrage, **Monetisation** (affiliates + banners, Adsterra ad code, rewarded video, per-slot switches), Homepage, Settings, **Storage & Backup** (counts, 7-day cleanup, duplicates, backup/restore), **Publishing** (sends only what you changed, revert).

## Publishing safely with automation running
The editor sends only the files and items you changed. An item you edited wins over the automatic copy; automatic items you did not touch are kept; deletions are explicit. Edited matches are marked locked so automation will not overwrite them (results are still graded). If you publish while the Worker has updated results, the Worker re-grades them on its next run.

## API budget (API-Football free: 100 requests/day, resets 00:00 UTC)
Default schedule (5 leagues): fixtures 5, odds 5 per refresh (3 refreshes), predictions up to 10, results 1 to 2 per check while selections are waiting: roughly 30 to 40 a day, about 1,000 to 1,200 a month of 3,000. The Worker never spends the last 15 requests of the day, caps each run at 25, caches repeated requests (minutes are editable), pauses if the key is rejected, backs off after errors and never retries in a loop. The Usage panel shows real numbers.

## Know the limits
- API-Football odds are pre-match snapshots, often refreshed about once a day. "Arbitrage" entries may already be gone. They expire when odds change or the match starts, and the site says so. Treat it as odds comparison, not guaranteed profit.
- Only one data provider is built in (API-Football). The provider list and key storage are ready for more, but a new provider needs its own adapter.
- Confirm with API-Football support that your plan allows a public, ad-supported site.
- Adsterra only needs ad code pasted into a slot. Never paste Adsterra passwords or API tokens into the editor.
- Rewarded video needs a provider that supports it; the page credits coins only when the provider's own completion callback fires.
- On the free Cloudflare Worker plan the CPU limit is small. If the activity log shows a CPU error, lower "Tickets built per 15-minute run".
- Everything was tested against simulated API-Football and GitHub responses. First real run: use Fetch now and read the activity log.

## Tests
`node tests/worker.test.js` (33 tests: credential encryption, publishing and merging, scheduling, quota guard, arbitrage maths, matches, duplicates, accumulators, 7-day cleanup, results, revert).
